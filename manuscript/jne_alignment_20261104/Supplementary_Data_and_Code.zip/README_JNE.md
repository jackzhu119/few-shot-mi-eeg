# Data and analysis code

**Description:** Saved derived predictions, participant and session tables, figure data, analysis scripts, input provenance, software checks and reconstruction instructions accompanying the fixed scientific results.

JNE format revision of the fixed scientific results at e5969e6ee6294206954b5a83c5258fdb2e143eda. All 1,392 historical archive entries are retained byte for byte, including their historical BMT paths. Current JNE materials are under manuscript/jne_alignment_20261104. See its REPRODUCTION.md for saved-result-only commands. No raw EEG, model weights or credentials are included.
