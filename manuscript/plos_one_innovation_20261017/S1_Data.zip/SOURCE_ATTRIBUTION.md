# Source attribution and redistribution boundary

The underlying dataset is Kumar2024 at NEMAR **nm000177, version 1.0.5**,
version DOI https://doi.org/10.82901/nemar.nm000177.v1.0.5, under its stated
**Creative Commons Attribution 4.0 International** terms.

Credit the dataset creators identified by that official versioned release and
Kumar and colleagues, *Transfer learning promotes acquisition of individual
BCI skills*, https://doi.org/10.1093/pnasnexus/pgae076, with correction
https://doi.org/10.1093/pnasnexus/pgae137. These source creators retain authorship
of source annotations, event identities and provider metadata. Ziyuan Zhu's
secondary derived tables and authored documentation are separately credited.

The repository is https://github.com/jackzhu119/few-shot-mi-eeg. The enclosing
release manifest records the published revision/tag and actual output hashes;
this package records its actual bytes and source-base commit without claiming
a self-containing final commit SHA or a newly minted archive DOI.

This is a derived numeric-text companion, not a redistribution of the raw EEG,
trial tensors, feature matrices, trained parameters, third-party study text or
complete software stack. Original cue/task marker semantics and published task
durations remain attributed literature/codebook evidence; missing within-trial
POS/TYP sequences and unobserved phase proportions are not invented here.
