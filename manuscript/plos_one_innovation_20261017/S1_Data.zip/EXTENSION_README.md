# S1 Data extension: component updating and prediction transitions

This archive preserves every byte of the 69 original members from the 16 October scientific data package and adds the 17 October 2026 saved-prediction analysis. Start with this file for the extension.

## Which manifest and instructions to use

`MANIFEST.json`, `README.md`, `REPRODUCE_SAVED_RESULTS.md`, the original licensing files and every other original member are historical files retained unchanged. They continue to describe their original analysis or release. `EXTENSION_MANIFEST.json` inventories all 69 preserved original members and every added payload member, recording their byte lengths and SHA-256 hashes. Its own hash is necessarily recorded outside itself in the accompanying package manifest. `EXTENSION_LICENSE_AND_ATTRIBUTION.md` states the component-specific terms for this addition.

## Standalone reproduction

From the extracted archive root, run:

```bash
python code/analyze_kumar_update_mechanisms_20261017.py \
  --inputs inputs \
  --output reproduced_extension
```

The output directory must not already exist. This command uses the original `inputs/saved_predictions.csv`, frozen metadata, configuration and participant endpoints together with the added `inputs/update_mechanism_source_texts.json`. The latter contains hashed historical CPU prediction/audit text and phase-status metadata required to recheck identity, label budgets and the original four paired statistical checks. It contains no EEG signal arrays or model weights. No repository checkout, model fitting or neural-model inference is required.

The tested arithmetic environment is Python 3.12.14 and NumPy 2.3.5. The standalone script uses Python 3.11-compatible syntax and requires NumPy. Optional figure rendering also uses Matplotlib 3.10.8 and Pillow 12.3.0 and requires actual licensed Arial or Times New Roman fonts. Fonts and software dependency distributions are not included. The three `--figures`, `--font-dir` and `--no-figures` options are described by the script's `--help`; omitting `--figures` gives an arithmetic-only replay.

## Added results and validation

`results/update_mechanisms/` contains 12 CSV tables and six scientific JSON files. They include individual saved CPU decisions, session/class transitions, participant/class averages, cohort bootstrap summaries, joint component gains, session profiles, leave-one-participant-out values, reconstructed original endpoints, matched fitting-budget checks, role/class counts and class-coverage checks.

Every contrast is included: LDA-only minus frozen, full refit minus LDA-only, and full refit minus frozen. Both true classes, all five target sessions, the development cohort of six, the primary cohort of twelve, and the secondary all-18 summary remain explicit. Balanced quantities first average the two class rates, then five sessions within participant, then participants equally. All bootstrap intervals resample participants, using 10,000 replicates and seed 42. The newly added analyses are post-observation exploratory; the original four-check sign-flip/Holm family is re-enumerated without new hypothesis tests.

Compare the 12 generated CSVs and six scientific JSONs by name against `results/update_mechanisms/`. Execution receipts contain runtime or time-dependent information and are not expected to have identical execution timestamps. `validation/update_mechanisms/` retains the initial execution receipt, independent portable replay record and figure QA records. The original execution receipt identifies the initial script version; subsequent changes affected figure label placement and font-size checks. The packaged script is pinned by the extension manifest and has been replayed directly from the final archive.

`figures/Fig5_source_data.csv` supplies the full cohort/class transition intervals. Fig6 has separate participant, session and influence source tables. The raster/vector figure uploads are distributed with the manuscript separately.

The phase follow-up status is reported explicitly: original-event metadata cover 311 of 360 runs and 6,220 of 7,200 trials. Label-budget, alignment/selector and phase-specific decoding extensions are implementation, metadata or synthetic-validation work in the reviewed snapshot; they are not presented as completed new decoding experiments.
