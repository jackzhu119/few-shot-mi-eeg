# Extension licensing and source attribution

Copyright (c) 2026 Ziyuan Zhu for the original contributions identified below. This extension follows the component-specific grant for S1 Data and its successor packages in the repository's `LICENSING.md`. The complete MIT and CC BY 4.0 legal texts already present in `LICENSES/` are retained unchanged.

| Added component | Applicable terms | Attribution and scope |
| --- | --- | --- |
| `code/analyze_kumar_update_mechanisms_20261017.py` | MIT | Original project analysis/reproduction software by Ziyuan Zhu. See `LICENSES/MIT.txt`. |
| Original added derived tables, figure source tables, analysis documentation and authored audit records | CC BY 4.0, to the extent of the author's rights | Attribute Ziyuan Zhu (2026), this paper-2 component-analysis extension, and the actual repository/version. See `LICENSES/CC-BY-4.0.txt`. |
| Existing source-derived event identities, class labels, recording metadata and their copied portions inside the portable source-text bundle | Original source CC BY 4.0 and retained source attribution | Kumar2024/NEMAR nm000177/v1.0.5; attribution remains with the source creators. Inclusion does not transfer authorship to the secondary analyst. |
| Preserved original 69 members and third-party material they identify | Existing component-specific notices | Their bytes, licensing notices and source credits are unchanged; this extension does not relicense them. |

Source dataset: Kumar2024, NEMAR nm000177 version 1.0.5, DOI https://doi.org/10.82901/nemar.nm000177.v1.0.5. Source access and attribution details are retained in `SOURCE_ATTRIBUTION.md`, `SOURCE_PROVENANCE.json` and the original input provenance. Original-analysis repository: https://github.com/jackzhu119/few-shot-mi-eeg. The added analysis starts from commit `30f23ed3c9afd271a3821fceaa99ab932bf25e5f`; the paper and export manifests identify the subsequent revision.

Suggested attribution for the original added content: “Ziyuan Zhu (2026), Spatial-filter refitting improves limited-label recalibration in longitudinal motor-imagery EEG: saved-prediction component-analysis extension,” with the actual repository/version URL. Link to https://creativecommons.org/licenses/by/4.0/, preserve source credits and identify changes. No journal acceptance or journal DOI is asserted.

NumPy, Matplotlib, Pillow, other software dependencies and font files retain their own licenses and are not redistributed here. Raw EEG, feature/epoch arrays, model checkpoints and learned weights, credentials, environment archives, original article full text, downloaded fonts and third-party rendering assets are excluded. The author's grant applies only to original material within its stated scope.
