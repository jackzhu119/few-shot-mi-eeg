# S1 Data component-specific licensing — 2026-10-16

Copyright (c) 2026 Ziyuan Zhu for the original contributions identified here.
The author approved this operative license choice on 2026-10-16. This is not a
blanket license for all source materials or software dependencies.

- Original Python software in `code/` and `tests/` is MIT; the complete grant
  is in `LICENSES/MIT.txt` and the scoped root notice is in `LICENSE`.
- Original derived numerical results, predictions, training-history summaries,
  authored annotations, methods and documentation are CC BY 4.0, to the extent
  of the author's rights; full legal code is in `LICENSES/CC-BY-4.0.txt`.
- Source-derived event IDs, labels and provider metadata retain the source
  creators' authorship, attribution and CC BY 4.0 terms. See
  `SOURCE_ATTRIBUTION.md`. This package does not claim authorship of source data.
- Third-party software, fonts, CSL styles, published articles and source code
  retain their existing terms. None is relicensed as MIT by a dependency name,
  citation or this package. No vendor software, font, CSL, source-paper full text,
  raw EEG, learned weights or environment archive is included here. The MIT and
  CC BY license texts are included expressly as license notices.

`provenance/repository_LICENSING_20261016.md` is the exact broader repository
notice at packaging. Its repository-wide scope-manifest link is resolved in the
repository, not by claiming that this smaller package contains that inventory.
`MANIFEST.json` is this package's current component inventory, hashes and license
classification. The three documents under `provenance/historical_20261015/`
are unchanged historical snapshots: their then-pending-license statements do
not supersede this current grant or the current reproduction instructions.

Suggested original-content attribution: Ziyuan Zhu (2026), Longitudinal
motor-imagery EEG decoding: Frozen baselines, supervised recalibration, and
task-measurement reliability; cite the actual repository revision/version and
CC BY 4.0, retain source credits and state any changes. No journal acceptance,
new DOI, ethics clearance or completed submission is asserted by this notice.
