# PONE-D-26-52050：2026年10月19日修订提交材料

本包整理自GitHub固定提交 `a5efb6078ece84302201556b076f189e8625a577`，未重新修改论文。

## 需要上传：01_UPLOAD_FILES，共12份

| 文件 | 类别/用途 |
| --- | --- |
| PLOS_ONE_Manuscript_Submission.docx | Manuscript（正式主稿，包含可编辑表格与图注） |
| Fig1.tif–Fig6.tif | Figure（按图号逐张上传，共6张） |
| S1_Text.pdf | Supporting Information：S1 Text |
| S2_Text.pdf | Supporting Information：S2 Text |
| S1_Data.zip | Supporting Information：S1 Data；保持ZIP原样上传 |
| Cover_Letter.pdf | Cover Letter |
| Human_Participants_Checklist.pdf | Other / Human Participants Research Checklist（按系统实际选项） |

## 需要复制进系统：02_SYSTEM_FIELDS

- `Ethics_Statement_20261019.md`：最新完整英文伦理声明，依据第32条第（一）项法规豁免，已删除学校确认。
- `Copy_Paste_System_Fields.txt`：题名、短标题、既有关键词、266词摘要、资助、利益冲突、数据可用性、AI辅助和作者贡献。
- `Author_Submission_Details.md`：作者、单位、通讯地址、邮箱、ORCID及作者信息记录；仅供填写和核对。
- `Abstract.txt`、`Data_Availability.txt`、`Funding_and_Competing_Interests.txt`：对应字段的单独副本。

请解压整个交付包后，分别上传01文件夹内的文件。整个交付包本身不作为主稿上传。`S1_Data.zip`作为一个数据附件上传，不解包后逐项上传。02文件夹、README和校验文件供填写/核对，不作为重复主稿或研究附件上传。

稿件已有编号PONE-D-26-52050，请在原稿件可编辑/返修入口按期刊允许的流程替换；不要新建重复投稿。本次交付没有操作期刊系统，也没有把作者内部编辑意见当作正式期刊审稿意见。

新版checklist第3项对应正式主稿第6页95–100行。完成替换后，核对系统生成的合并PDF中的正文、表格、图号、补充材料标签和伦理字段是否为本版。

文件名/文件夹沿用20261017投稿系列名的部分，实际内容均为20261019已核验修订。

本次补充核查run02仅调整指定措辞。Table6原正确区间9.91 [−1.46, 21.75]未改，其余统计数字、伦理声明、图件、S1/S2和checklist不变。请以本run02包中的主稿替换较早下载包中的主稿。
