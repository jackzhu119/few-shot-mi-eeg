# 论文2：科研贡献导向修订（2026-10-17）

GitHub 提交：5c32064d8a16db999ba1c9c044313edb582f92f9

研究分支：research/learning-preserving-bci

[在线修订入口](https://github.com/jackzhu119/few-shot-mi-eeg/tree/5c32064d8a16db999ba1c9c044313edb582f92f9/manuscript/plos_one_revision_20261017)

## 建议阅读顺序

1. [带图主稿 PDF](manuscript/plos_one_revision_20261017/PLOS_ONE_Manuscript_Revised.pdf)
2. [可编辑主稿 Word](manuscript/plos_one_revision_20261017/PLOS_ONE_Manuscript_Revised.docx)
3. [完整文件索引](manuscript/plos_one_revision_20261017/README.md)
4. [中文修改说明](docs/kumar_editorial_revision_20261017.md)

本包包含主稿的带图版与投稿排版版、S1 方法、S2 复现说明和附信，共五份 Word 与五份 PDF；另附四张原始 TIFF 图、原有 S1 Data 数据包、正文源稿、参考文献、文档构建脚本和适用许可说明。

源稿和构建依赖保持仓库中的相对目录，可在本包根目录运行文档构建脚本。原科学结果的完整历史记录及后续任务阶段方案见 GitHub 仓库。
